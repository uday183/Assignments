from django.apps import AppConfig


class DataappConfig(AppConfig):
    name = 'dataapp'
