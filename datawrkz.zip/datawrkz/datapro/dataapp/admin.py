from django.contrib import admin
from dataapp.models import dataworkz
# Register your models here.
admin.site.register(dataworkz)