from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Book
from .serializers import BookSerializer
# Create your views here.


class BookInformation(APIView):
    def get(self,request):
        #import ipdb; ipdb.set_trace()
        books_data=Book.objects.all()
        ids=request.GET.get('id')
        if ids:
            book_obj=books_data.filter(id=ids)
        else:
            book_obj=books_data
        serializer = BookSerializer(book_obj, many=True)
        return Response(serializer.data)

    def post(self,request):
        title = request.data.get('title')
        description =request.data.get('description')
        published =request.data.get('published')
        Book(title=title,description=description,published=published).save()
        return Response('saved...')

    def put(self,request):
        ids=request.data.get('id')
        title = request.data.get('title')
        Book.objects.filter(id=ids).update(title=title)
        return Response('updated...')

    def delete(self,request):
        ids=request.data.get('id')
        Book.objects.filter(id=ids).delete()
        return Response('updated...')